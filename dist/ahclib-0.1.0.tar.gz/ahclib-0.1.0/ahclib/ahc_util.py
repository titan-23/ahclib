def to_red(arg) -> str:
    return f"\u001b[91m{arg}\u001b[0m"


def to_blue(arg) -> str:
    return f"\u001b[94m{arg}\u001b[0m"


def to_green(arg) -> str:
    return f"\u001b[92m{arg}\u001b[0m"


def to_bold(arg) -> str:
    return f"\u001b[1m{arg}\u001b[0m"
